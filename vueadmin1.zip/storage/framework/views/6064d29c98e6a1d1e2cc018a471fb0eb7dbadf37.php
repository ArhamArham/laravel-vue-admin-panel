<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('public/css/app.css')); ?>">
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="" rel="stylesheet">
<link href="" rel="stylesheet">

    </head>
    <body>
        <div id="app">
            <App/>
        </div>
    </body>
    <script src="<?php echo e(asset('public/js/app.js')); ?>"></script>
</html>
<?php /**PATH C:\xampp\htdocs\vueadmin\resources\views/welcome.blade.php ENDPATH**/ ?>